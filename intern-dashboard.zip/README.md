# 实习工作台 · 网页维护指南

## 一、文件说明

- `intern-dashboard.html` — 主页面，所有内容（结构/样式/数据/交互）全部内嵌在一个文件里
- `dashboard-data.js` — 独立数据文件（备用），当前版本数据已内嵌在 HTML 中，此文件供参考
- 本项目为纯静态单文件，零外部依赖，双击 HTML 即可在浏览器打开

## 二、网页结构

导航栏三个分页，通过蓝色渐变导航切换：
- **工作概览** — 月视图日历事件
- **AI 实践** — Skill 卡片 + AI 赋能实践报告
- **培训研习实录** — 培训课程手风琴 + 右侧时间选择侧栏

## 三、数据更新位置

打开 `intern-dashboard.html`，搜索 `<script>` 标签，在第一个 `<script>` 块顶部有四个数据变量：

### 1. 日历事件 — `CALENDAR_DATA`
```javascript
var CALENDAR_DATA = {
  "2026-07-02": ["事件1", "事件2"],
  "2026-07-17": ["新增事件..."]
};
```
按 `YYYY-MM-DD` 格式添加即可，同一天可放多条事件。

### 2. Skill 卡片 — `SKILLS_DATA`
```javascript
var SKILLS_DATA = [
  {
    icon: "📊",
    title: "Skill名称",
    color: "#EDF3FF",
    tags: ["标签1", "标签2", "标签3"],   // 卡片显示前2个，溢出显示蓝字"更多"
    desc: "一句话简介",
    details: [
      { heading: "使用场景", content: "..." },
      { heading: "功能简介", content: "..." },
      { heading: "核心价值", content: "..." }
    ]
  },
  // 新增Skill追加到这里
];
```
Skill 每页显示 5 个，超过自动翻页（◂ ▸ 按钮）。

### 3. AI 实践报告 — `AI_REPORTS_DATA`
```javascript
var AI_REPORTS_DATA = [
  {
    domain: "电商运营",     // 领域名（会出现在筛选按钮中）
    reports: [
      {
        title: "报告标题",
        role: "岗位名称",
        tools: ["工具1", "工具2"],
        result: "效果数据",
        insights: ["洞察金句1", "洞察金句2", "洞察金句3"],
        table: [
          ["任务名", "痛点", "AI解决方案", "效果评价"],
          // 更多行...
        ]
      }
    ]
  }
];
```
每个 domain 对象对应一个筛选按钮。新增领域直接追加新的 domain 对象。

### 4. 培训记录 — `TRAINING_DATA`
在 HTML 靠后的位置（第二个 `<script>` 块），通过 `TRAINING_DATA.push(...)` 追加：
```javascript
TRAINING_DATA.push(
  {
    date: "2026-07-17",
    title: "培训课程标题",
    summary: "一句话概括（未展开时显示在标题下方）",
    sections: [
      { heading: "一、章节标题", content: "章节具体内容..." },
      { heading: "二、章节标题", content: "..." }
    ]
  }
);
```

### 5. 导航栏副标题
搜索文本 `凡岛大学人才发展实习生工作记录`，修改即可。

## 四、设计规范速查

| 元素 | 值 |
|------|-----|
| 导航底色 | `linear-gradient(135deg, #2B5FED, #1E40AF, #1E3A8A)` |
| 主蓝色 | `#3B7DFF` |
| 卡片边框 | `1px solid #E5E6EB` |
| 蓝色标签 | `background:#EDF3FF; color:#2563EB` |
| 橙色标签 | `background:#FFF7ED; color:#EA580C` |
| 绿色标签 | `background:#EDFFF5; color:#059669` |
| 日历格子高度 | `min-height: 95px` |
| 日历翻页按钮 | 28px 圆圈, 14px 箭头 |
| Skill 翻页按钮 | 16px 字体, 42px 最小宽度 |

## 五、关键 CSS 类

| 类名 | 用途 |
|------|------|
| `.panel` | 三个分页面板 |
| `.calendar-day` | 日历每个日期格子 |
| `.accordion-item` | 培训手风琴条目 |
| `.report-card` | AI 实践报告卡片 |
| `.skill-card` | Skill 卡片 |
| `.filter-bar` / `.filter-pill` | 筛选按钮 |
| `.training-sidebar` / `.training-sidebar-pill` | 培训时间选择侧栏 |
| `.modal-overlay` / `.modal-box` | 弹窗 |

## 六、注意事项

- **都是纯 JavaScript，不是 JSON** — 注意变量名和分号
- **中英文之间不要加空格** — 数据中用中文标点（，、：）不用英文逗号
- **emoji 图标可以自由替换** — Skill 卡片的 `icon` 字段
- **培训条目中 `summary`** 会被截断到 60 字显示在标题下方
- **弹窗标签位置** — 在 `modal-head` 的 `#modal-tags` 中渲染
