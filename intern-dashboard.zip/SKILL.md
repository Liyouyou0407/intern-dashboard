# 实习工作台网页维护 Skill

## 一、项目概述

这是一个自包含的单文件 HTML 网页项目，位于 `intern-dashboard/` 目录下。

**核心特征：**
- 单个 `intern-dashboard.html` 文件承载所有内容（HTML/CSS/JS/数据）
- 零外部依赖（无 CDN、无外部字体、无网络请求）
- 设计风格参考字节跳动社招官网：白底 + 蓝色渐变导航 + 细线卡片
- 导航栏分三页：工作概览（日历）/ AI 实践 / 培训研习实录

## 二、数据维护方式

所有数据存储在 `intern-dashboard.html` 文件内的 `<script>` 标签中。

### 四个数据变量（在第一个 `<script>` 块顶部）：
1. `var CALENDAR_DATA = { "2026-07-17": ["事件A", "事件B"] }` — 日历事件
2. `var SKILLS_DATA = [{ icon, title, color, tags, desc, details }]` — Skill 卡片（每页5个）
3. `var AI_REPORTS_DATA = [{ domain, reports: [{ title, role, tools, result, insights, table }] }]` — AI 实践报告
4. `var TRAINING_DATA` — 通过 `TRAINING_DATA.push()` 追加（在第二个 `<script>` 块中）

### 添加条目模板：

**新增 Skill：**
```javascript
{icon:"🔧",title:"新Skill名称",color:"#EDF3FF",tags:["标签1","标签2"],desc:"一句话简介",details:[
  {heading:"使用场景",content:"..."},
  {heading:"功能简介",content:"..."},
  {heading:"核心价值",content:"..."}
]}
```

**新增培训记录：**
```javascript
TRAINING_DATA.push(
  {date:"2026-MM-DD",title:"课程标题",summary:"一句话概括（60字内）",sections:[
    {heading:"一、章节名",content:"具体内容"}
  ]}
);
```

**新增 AI 报告（现有5个领域：电商运营/设计/摄影/营销/视频编辑）：**
```javascript
{title:"报告标题",role:"岗位",tools:["工具"],result:"效果",insights:["洞察1","洞察2"],table:[["任务","痛点","方案","效果"]]}
```

## 三、设计规范

| 元素 | 值 |
|------|-----|
| 导航栏背景 | `linear-gradient(135deg, #2B5FED, #1E40AF, #1E3A8A)` |
| 主蓝色 | `#3B7DFF` |
| 卡片边框色 | `#E5E6EB` |
| 标签蓝底 | `#EDF3FF` |
| 日历格子 | `min-height: 95px` |
| 日历翻页按钮 | 28px圆圈，14px字体 |
| Skill翻页按钮 | 16px字体，圆角胶囊形 |
| 弹窗标签 | 在 `modal-head` 内 `#modal-tags` 区域渲染 |

## 四、每次修改后必须执行

```powershell
$desktop = [Environment]::GetFolderPath("Desktop")
Copy-Item "$desktop\intern-dashboard\intern-dashboard.html" -Destination "C:\Users\admin\AppData\Roaming\FanDo\openclaw\workspace\intern-dashboard.html" -Force
Compress-Archive -Path "$desktop\intern-dashboard\*" -DestinationPath "$desktop\intern-dashboard.zip" -Force
```

同时更新 workspace 版本并重新打包 ZIP。
